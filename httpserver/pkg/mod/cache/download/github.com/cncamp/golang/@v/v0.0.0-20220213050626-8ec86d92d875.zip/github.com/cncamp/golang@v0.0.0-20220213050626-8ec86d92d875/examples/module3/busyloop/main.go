package main

func main() {
	go func() {
		for {
		}
	}()
	for {

	}
}
