package b

import (
	"fmt"
)

func init() {
	fmt.Println("init from b")
}
